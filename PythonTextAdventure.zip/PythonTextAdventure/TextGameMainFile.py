# Tyler Walker's Madhouse Masterpiece (hopefully)
import random  # For damage taken

player_hp = 5  # The interface told me I should establish this variable up here too for some reason


def status():  # Per the feedback tool's advice, I have added a status screen option to the UI. Actually super cool!
    print(f'You are in {current_room}')
    print(f'You can go {list(rooms[current_room].keys())}')
    print(f'Your inventory currently is \n{inventory}')
    print(f'You can inspect {list(clues_and_items[current_room].keys())}')
    print(f'Your current HP is {player_hp}')
    get_input()


def help_menu():  # Prints out a help menu for the player upon startup and upon player request with an input
    print('Move: Type "go" and the direction you would like to go.\n\nInspect: Type "inspect" and the \nobject in the'
          'room you would like to inspect.\n\nCheck Inventory: You can check your inventory at\nany time by typing '
          '"check" and the item you wish to check.\n\n'
          'Using an item: You may use items in your inventory by typing "use" and'
          '\nthe item you wish to use, if able.'
          '\nType "status" for full details of your location and inventory at any time.\n'
          'Type "help" whenever you need to have these instructions repeated.')
    status()


def final_sequence():  # Plays the final 'cutscene' of the game once the player enters the final room
    if 'Gas Mask' not in inventory:
        description_text = open('ItemDescriptions/NoGasMaskEnding')
        description = description_text.read()
        description_text.close()
        print(description)
        print('Game Over')
        quit()
    elif 'Photograph' not in inventory:
        description_text = open('ItemDescriptions/NoPhotoEnding')
        description = description_text.read()
        description_text.close()
        print(description)
        print('Game Over')
        quit()
    if ('Photograph' in inventory) and ('Gas Mask' in inventory):
        if 'Loaded Shotgun' in inventory:
            description_text = open('ItemDescriptions/GoodEnding.txt')
            description = description_text.read()
            description_text.close()
            print(description)
            quit()
        else:
            description_text = open('ItemDescriptions/UnpreparedEnding')
            description = description_text.read()
            description_text.close()
            print(description)
            quit()


def trap_trigger():  # This function will trigger whenever a mistake is made by the player, reducing the player's hp
    global player_hp
    damage = random.randint(1, 5)
    if 1 < damage < 3:
        player_hp -= damage
        if player_hp > 0:
            print(f'You took {damage} damage.')
            status()
    elif damage >= 3:
        player_hp -= damage
        if player_hp > 0:
            print(f'You took {damage} damage.')
            status()
    if player_hp <= 0:  # Checks for player being at 0HP, and triggers a death scene depending on the room of the player
        if current_room == 'Water Room':
            description_text = open('ItemDescriptions/WaterRoomDeath')
            description = description_text.read()
            description_text.close()
            print(description)
        if current_room == 'Foyer':
            description_text = open('ItemDescriptions/FoyerDeath')
            description = description_text.read()
            description_text.close()
            print(description)
        if current_room == 'Password Room':
            description_text = open('ItemDescriptions/PasswordRoomDeath')
            description = description_text.read()
            description_text.close()
            print(description)
        print('RIP')
        quit()


def item_description():  # Reads out a pre-written description of an item in the player's inventory
    global puzzler_identity_known
    item = ' '.join(userInput[1:])
    if item == 'Tape Recorder':
        description_text = open('ItemDescriptions/TapeRecorderDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Photograph') or (item == 'photograph'):
        description_text = open('ItemDescriptions/PhotoDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
        if not puzzler_identity_known:
            puzzler_identity_known = True
    if (item == 'Clue #1') or (item == 'clue #1'):
        description_text = open('ItemDescriptions/Clue1Desc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Blue Puzzle Piece') or (item == 'blue puzzle piece'):
        description_text = open('ItemDescriptions/BluePuzzlePieceDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Rubber Boots') or (item == 'rubber boots'):
        description_text = open('ItemDescriptions/RubberBootsDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Shotgun') or (item == 'shotgun'):
        description_text = open('ItemDescriptions/ShotgunDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Red Puzzle Piece') or (item == 'red puzzle piece'):
        description_text = open('ItemDescriptions/RedPuzzlePieceDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Yellow Puzzle Piece') or (item == 'yellow puzzle piece'):
        description_text = open('ItemDescriptions/YellowPuzzlePieceDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Steel Rod') or (item == 'steel rod'):
        description_text = open('ItemDescriptions/SteelRodDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Gas Mask') or (item == 'gas mask'):
        description_text = open('ItemDescriptions/GasMaskDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Bullet') or (item == 'bullet'):
        description_text = open('ItemDescriptions/BulletDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Clue #3') or (item == 'clue #3'):
        description_text = open('ItemDescriptions/Clue3Desc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Password') or (item == 'password'):
        description_text = open('ItemDescriptions/PasswordDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Key') or (item == 'key'):
        description_text = open('ItemDescriptions/KeyDesc.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if (item == 'Loaded Shotgun') or (item == 'loaded shotgun'):
        description_text = open('ItemDescriptions/LoadedShotgunDesc')
        description = description_text.read()
        description_text.close()
        print(description)


def check_locks():  # This function checks the locked door at the end of the game.
    global current_room
    global userInput
    global blue_piece_in_door
    global red_piece_in_door
    global yellow_piece_in_door
    global puzzler_room_open
    if current_room == 'Safe Haven':
        puzzler_room_open = False
        print('This door is locked.')
    if not blue_piece_in_door:
        if 'Blue Puzzle Piece' in inventory:
            print('You placed the Blue Puzzle Piece in the slot.')
            inventory.remove('Blue Puzzle Piece')
            blue_piece_in_door = True
    if not red_piece_in_door:
        if 'Red Puzzle Piece' in inventory:
            print('You placed the Red Puzzle Piece in the slot.')
            inventory.remove('Red Puzzle Piece')
            red_piece_in_door = True
    if not yellow_piece_in_door:
        if 'Yellow Puzzle Piece' in inventory:
            print('You placed the Yellow Puzzle Piece in the slot.')
            inventory.remove('Yellow Puzzle Piece')
            yellow_piece_in_door = True
    if blue_piece_in_door:
        if red_piece_in_door:
            if yellow_piece_in_door:
                puzzler_room_open = True
    if puzzler_room_open:
        current_room = rooms[current_room][userInput[1]]
        final_sequence()
        quit()
    current_room = 'Safe Haven'
    status()


def investigate():  # Reads pre-written descriptions of the investigations, and adds items to inventory when applicable
    global current_room
    if current_room == 'Empty Room':
        if 'Tape Recorder' not in inventory:
            description_text = open('ItemDescriptions/ManWRecorder')
            description = description_text.read()
            description_text.close()
            print(description)
            get_item()
        if 'Tape Recorder' in inventory:  # Upon re-investigation, there is a different description for each option!
            description_text = open('ItemDescriptions/ManDesc.txt')
            description = description_text.read()
            description_text.close()
            print(description)
            status()
    if current_room == 'Pendulum Room':
        if userInput[1] == 'wardrobe':
            if 'Key' not in inventory:
                description_text = open('ItemDescriptions/ArmoireDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
            if 'Key' in inventory:
                description_text = open('ItemDescriptions/ArmoireWKeyDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
        if userInput[1] == 'mirror':
            if 'Clue #1' not in inventory:
                description_text = open('ItemDescriptions/MirrorDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if 'Clue #1' in inventory:
                description_text = open('ItemDescriptions/MirrorSearched')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
        if userInput[1] == 'floor':
            if 'Blue Puzzle Piece' not in inventory:
                description_text = open('ItemDescriptions/PendulumFloorDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if 'Blue Puzzle Piece' in inventory:
                description_text = open('ItemDescriptions/PendFloorSearched')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
    if current_room == 'Foyer':
        if userInput[1] == 'entryway':
            if 'Rubber Boots' not in inventory:
                description_text = open('ItemDescriptions/EntrywayDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if 'Rubber Boots' in inventory:
                description_text = open('ItemDescriptions/SearchedEntryway')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
        if userInput[1] == 'safe':
            if not safe_open:
                description_text = open('ItemDescriptions/SafeDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
            if safe_open:
                description_text = open('ItemDescriptions/OpenSafeDesc')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
        if userInput[1] == 'fireplace':
            if 'Red Puzzle Piece' not in inventory:
                description_text = open('ItemDescriptions/FireplaceDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if 'Red Puzzle Piece' in inventory:
                description_text = open('ItemDescriptions/SearchedFireplace')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
    if current_room == 'Water Room':
        if 'Rubber Boots' in inventory:
            description_text = open('ItemDescriptions/MetalRodDesc.txt')
            description = description_text.read()
            description_text.close()
            print(description)
            get_item()
        else:
            trap_trigger()  # Triggers a trap if you do not have the rubber boots
    if current_room == 'Password Room':
        global keypad_password
        if userInput[1] == 'keypad':
            if not keypad_solved:
                description_text = open('ItemDescriptions/KeypadDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
            if keypad_solved:
                description_text = open('ItemDescriptions/SolvedKeypad')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
        if userInput[1] == 'mug':
            if ('Bullet' not in inventory) and ('Loaded Shotgun' not in inventory):
                description_text = open('ItemDescriptions/MugwBulletDesc')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if ('Bullet' in inventory) or ('Loaded Shotgun' in inventory):
                description_text = open('ItemDescriptions/MugDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
    if current_room == 'Spike Wall Room':
        if userInput[1] == 'button':
            if 'Clue #3' not in inventory:
                description_text = open('ItemDescriptions/ButtonDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                if 'Steel Rod' not in inventory:
                    description_text = open('ItemDescriptions/SpikeRoomDeath.txt')
                    description = description_text.read()
                    description_text.close()
                    print(description)
                    quit()
                else:
                    print('Maybe you have something to buy some time?')
                    life_saver = input('What do you use?:').split()
                    if life_saver[0] == 'use':
                        if ' '.join(life_saver[1:]) == 'Steel Rod':
                            description_text = open('ItemDescriptions/SpikeRoomEscape.txt')
                            description = description_text.read()
                            description_text.close()
                            print(description)
                            print('You are back in the Password Room')
                            get_item()
                    else:
                        print("You should 'use' something here!")
                        life_saver = input('What do you use?:').split()
                        if ' '.join(life_saver[1:]) == 'Steel Rod':
                            description_text = open('ItemDescriptions/SpikeRoomEscape.txt')
                            description = description_text.read()
                            description_text.close()
                            print(description)
                            print('You are back in the Password Room')
                            get_item()
                        else:
                            description_text = open('ItemDescriptions/SpikeRoomDeath.txt')
                            description = description_text.read()
                            description_text.close()
                            print(description)
                            quit()
            if 'Clue #3' in inventory:
                description_text = open('ItemDescriptions/ButtonSearched')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
    if current_room == 'Safe Haven':
        if userInput[1] == 'diary':
            if 'Password' not in inventory:
                description_text = open('ItemDescriptions/DiaryDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if 'Password' in inventory:
                description_text = open('ItemDescriptions/DiaryRead')
                description = description_text.read()
                description_text.close()
                print(description)
                status()
        if userInput[1] == 'desk':
            if 'Key' not in inventory:
                description_text = open('ItemDescriptions/DeskDesc.txt')
                description = description_text.read()
                description_text.close()
                print(description)
                get_item()
            if 'Key' in inventory:
                description_text = open('ItemDescriptions/DeskSearched')
                description = description_text.read()
                description_text.close()
                print(description)
                status()


def get_item():  # The function to add items to inventory, or combine them in the gun and bullet's case
    global userInput
    global current_room
    item = clues_and_items[current_room][userInput[1]]
    if (item == 'Shotgun') and ('Bullet' in inventory):
        inventory.remove('Bullet')
        item = 'Loaded Shotgun'
    if (item == 'Bullet') and ('Shotgun' in inventory):
        inventory.remove('Shotgun')
        item = 'Loaded Shotgun'
    if item not in inventory:
        print('You got a {}!'.format(item))
        inventory.append(item)
        if current_room == 'Spike Wall Room':  # This was just a convenient spot to put this with how I wrote the scene
            current_room = 'Password Room'
        status()


def new_room():  # Runs a pre-written description of each room, for only the first time entering it
    if current_room == 'Empty Room':
        description_text = open('ItemDescriptions/Empty Room Description.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if current_room == 'Pendulum Room':
        description_text = open('ItemDescriptions/Pendulum Room Description.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if current_room == 'Foyer':
        description_text = open('ItemDescriptions/Foyer Description.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if current_room == 'Water Room':
        description_text = open('ItemDescriptions/Water Room Description.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if current_room == 'Password Room':
        description_text = open('ItemDescriptions/Password Room.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if current_room == 'Spike Wall Room':
        description_text = open('ItemDescriptions/Spike Wall Room Description.txt')
        description = description_text.read()
        description_text.close()
        print(description)
        print('You got a Yellow Puzzle Piece!')
        inventory.append('Yellow Puzzle Piece')
    if current_room == 'Safe Haven':
        description_text = open('ItemDescriptions/Safe Haven Room Description.txt')
        description = description_text.read()
        description_text.close()
        print(description)
    if current_room == "Puzzler's Lair":
        description_text = open("ItemDescriptions/Puzzler's Lair Description.txt")
        description = description_text.read()
        description_text.close()
        print(description)
    seen_rooms.append(current_room)

# I have decided to place all of my main input code into a self-referential function. It re-initializes from the top
# whenever necessary. I was having some major mishaps trying to do it any other way, and this seemed to do the trick
# quite nicely. The feedback tool didn't like this so much, as it couldn't really comprehend my code haha. Hopefully
# it's not too much of a mess though. I've tried to comment enough to make sense of it all. Hope you enjoy Prof.!


def get_input():
    global userInput
    global current_room
    global keypad_solved
    global safe_open
    userInput = input('Enter a command:').split()  # Split the user's command to determine the type of action
    while userInput[0] not in quitCommands:
        if userInput[0] == 'status':
            status()
        if userInput[0] == 'go':  # Initializes the moving sequence for the player, and determines if it is viable
            print('Direction: {}'.format(userInput[1]))
            if (current_room == 'Safe Haven') and (userInput[1] == 'east'):
                check_locks()
            if userInput[1] in rooms[current_room]:
                current_room = rooms[current_room][userInput[1]]  # Changes the player's current room
                if current_room not in seen_rooms:
                    new_room()
                print(f'You are in the {current_room}.')
                print(f'You can go {list(rooms[current_room].keys())}')
                if current_room in clues_and_items:
                    print(f'You can inspect {list(clues_and_items[current_room].keys())}')
                status()
            else:  # Print out a contextual error message if the direction is invalid, but is valid otherwise
                print("You can't go {} right now.".format(userInput[1]))
                status()
        if userInput[0] == 'inspect':  # Allows the user to inspect items in their current room
            if ' '.join(userInput[1:]) in clues_and_items[current_room]:
                print('Inspecting: {}'.format(' '.join(userInput[1:])))
                investigate()  # runs the investigate function
            if userInput[1] == 'keypad':  # Checks for a yes or no and a correct response from the player
                if not keypad_solved:
                    print('Try to enter the password?')
                    decision = input('Yes or No?:')
                    if (decision == 'Yes') or (decision == 'yes'):
                        pw_guess = input("What's the password?(Case sensitive):")
                        if pw_guess == keypad_password:
                            description_text = open("ItemDescriptions/KeypadSolved.txt")
                            description = description_text.read()
                            description_text.close()
                            print(description)
                            keypad_solved = True
                            get_item()
                        if pw_guess != keypad_password:
                            trap_trigger()
                    if (decision == 'No') or (decision == 'no'):
                        get_input()
            if userInput[1] == 'safe':  # Runs a small function to check for user choice and a correct answer
                if not safe_open:
                    print('Try to open the safe?')
                    decision = input('Yes or No?:')
                    if (decision == 'Yes') or (decision == 'yes'):
                        safe_combo = input("What's the combination?(Use spaces between numbers):").split()
                        if safe_combo == true_safe_combo:
                            description_text = open("ItemDescriptions/SafeCrackedDesc.txt")
                            description = description_text.read()
                            description_text.close()
                            print(description)
                            get_item()
                            safe_open = True
                        if safe_combo != true_safe_combo:
                            trap_trigger()
                    if (decision == 'No') or (decision == 'no'):
                        print("You aren't feeling confident in your safe cracking skills at the moment.")
                        get_input()
            else:
                print("You can't inspect that, maybe you meant to 'check' something?")
                status()
        if userInput[0] == 'check':
            if userInput[1] == 'inventory':  # Allows the player to check their entire inventory
                print(inventory)
                status()
            else:
                if ' '.join(userInput[1:]) in inventory:
                    print(f'Checking {' '.join(userInput[1:])}')
                    item_description()  # Initializes the function to print an item description
                    status()
                else:
                    print("You can't check that.")  # Prints if the player types 'check' and then a false item
                    status()
        if userInput[0] == 'help':
            help_menu()
        if userInput[0] not in valid_inputs:  # Print a generic error message if the entered command is entirely invalid
            print("You can't do that right now.")
            status()


clues_and_items = {  # A dictionary of clues and their attached items
    'Empty Room': {'man': 'Tape Recorder'},
    'Pendulum Room': {'wardrobe': 'Photograph', 'mirror': 'Clue #1', 'floor': 'Blue Puzzle Piece'},
    'Foyer': {'entryway': 'Rubber Boots', 'safe': 'Shotgun', 'fireplace': 'Red Puzzle Piece'},
    'Water Room': {'pole': 'Steel Rod'},
    'Password Room': {'keypad': 'Gas Mask', 'mug': 'Bullet'},
    'Spike Wall Room': {'button': 'Clue #3'},
    'Safe Haven': {'diary': 'Password', 'desk': 'Key'}
}

rooms = {  # Starting off with a dictionary of rooms and viable move directions
    'Empty Room': {'west': 'Pendulum Room'},
    'Pendulum Room': {'north': 'Foyer', 'east': 'Empty Room'},
    'Foyer': {'west': 'Water Room', 'east': 'Password Room', 'south': 'Pendulum Room', 'north': 'Safe Haven'},
    'Water Room': {'east': 'Foyer'},
    'Password Room': {'north': 'Spike Wall Room', 'west': 'Foyer'},
    'Spike Wall Room': {'south': 'Password Room'},
    'Safe Haven': {'east': "Puzzler's Lair", 'south': 'Foyer'},
    "Puzzler's Lair": {},
    'Escape': {'anywhere': ''}  # Essentially here for a win condition trigger
}

seen_rooms = []  # This will be appended as the player enters new rooms for the first time
inventory = []  # This will be added to throughout the game, and sometimes taken away from
player_hp = 5  # This tracks the player's current health, which is basically a luck-out-o-meter
safe_open = False  # This will be flagged true once the safe is open
puzzler_identity_known = False  # This will be flagged true once the villain's identity has been found out
blue_piece_in_door = False  # These next three are conditional on checking the final door with the item in your stash
red_piece_in_door = False
yellow_piece_in_door = False
puzzler_room_open = False  # This is flagged as true upon unlocking the door, and immediately begins the final sequence
keypad_solved = False  # Flagged as false to allow the player multiple attempts to check the keypad for the solution
valid_inputs = ['go', 'inspect', 'check', 'status', 'help']  # Checks for valid input from the player
true_safe_combo = ['16', '45', '29']  # Stores the safe combo here
keypad_password = 'JIGSAW'  # Stores the keypad password here

print('Welcome to the game.')  # Startup sequence initializes here
quitCommands = ['Exit', 'Quit', 'leave']  # A variety of viable quit commands
current_room = 'Empty Room'  # Start the player in the Empty Room
new_room()  # Tells the player where they are
userInput = ''
help_menu()  # Prints out instructions and begins the game
