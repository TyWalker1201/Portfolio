/******************************
*bstree.h
*Assignment 17 CSCI241
*Writtnen by Tyler Walker Z2079757
*Creates a binary search tree template and holds all functions related to traversal of that tree
*****************************/

#ifndef BSTREE
#define BSTREE
#include <iostream>


using namespace std;

/******************************
*
*The structure of the binary search tree's nodes
*
*
*****************************/
template <class K, class V>
struct node
{
    K key;
    V value;
    node<K,V>* left;
    node<K,V>* right;

    node(const K& key = K(), const V& value = V(), node<K, V>* left = nullptr, node<K,V>* right = nullptr)
    {
        this->value = value;
        this->key = key;
        this->left = left;
        this->right = right;
    }
};

template <class K, class V>
class bstree {

public:
/******************************
*
*The default constructor for the tree
*
*
*****************************/

    bstree()
    {
        t_size = 0;
        root = nullptr;
    }
/******************************
*
*
*The destructor for the tree
*
*****************************/

    ~bstree()
    {
        clear();
    }
/******************************
*
*
*The copy constructor for a tree, which simply calls the clone function, defined later
*@param x: a constant reference to a binary tree being copied
*****************************/

    bstree(const bstree<K, V>& x)
    {
        t_size = x.t_size;
        root = clone(x.root);
    }
/******************************
*
*The copy assignment operator for a tree, behaving very similar to the copy constructor above
*@param x: the right side of the operation
*
*****************************/

    bstree<K, V>& operator=(const bstree<K, V>& x)
    {
        if (this != &x)
        {
            clear();

            t_size = x.t_size;

            root = clone(x.root);
        }

        return *this;
    }
/******************************
*
*
*Empties out the entire tree
*
*****************************/

    void clear()
    {
        destroy(root);
        root = nullptr;
        t_size = 0;
    }
/******************************
*
*
*Recursively destroys a node and all nodes below it
*@param p: the starting node to begin the recursive removal
*****************************/

    void destroy(node<K,V>* p)
    {
        if (p != nullptr)
        {
            destroy(p->left);
            destroy(p->right);

            delete p;
        }
    }
/******************************
*
*Returns the size of the tree
*
*
*****************************/

    size_t size() const
    {
        return t_size;
    }
/******************************
*
*
*Initiates the recursive height of the tree at the root if a starting node is not given
*
*****************************/

    size_t height() const
    {
        node<K,V>* p = root;
        return height(p);
    }
/******************************
*
*The recursive algorithm for returning the height of the tree
*@param p: The starting node to begin measuring the height from
*
*****************************/

    size_t height(node<K,V>* p) const
    {
        size_t l_height = 0;
        size_t r_height = 0;

        if (p == nullptr)
            return 0;

        l_height = height(p->left);
        r_height = height(p->right);

        if (l_height > r_height)
            return l_height + 1;
        else
            return r_height + 1;
    }
/******************************
*
*
*Checks if the tree is empty
*
*****************************/

    bool empty() const
    {
        if (t_size == 0)
            return true;
        else
            return false;
    }
/******************************
*
*Initiates the recursive traversal for the minimum key value
*
*
*****************************/
    const K& min() const
    {
        //node<K,V>* p = root;
        return min(root);
    }

/******************************
*
*Traverses the tree by continuing left until it finds the minimum key value
*@param p: Initialized as the root of the tree, then passed as whatever gets pointed to after that
*
*****************************/

    K& min(node<K,V>* p) const
    {
        if (p->left == nullptr)
            return p->key;
        
        return min(p->left);
    }
/******************************
*
*Initiates the recursive traversal for the maximum key value
*
*
*****************************/
    const K& max() const
    {
        //node<K,V>* p = root;
        return max(root);
    }
/******************************
*
*Traverses the tree by continuing right until it finds the maximum key value
*@param p: Initialized as the root of the tree, then passed as whatever gets pointed to after that
*
*****************************/
    const K& max(node<K,V>* p) const
    {
        if (p->right == nullptr)
            return p->key;
        
        return max(p->right);
    }
/******************************
*
*Inserts a new key into the tree in the proper location
*@param key: The key value to insert
*@param value: The value to link to the key
*****************************/
    bool insert(const K& key, const V& value)
    {
        node<K,V>* p = root;
        node<K,V>* parent = nullptr;

        while (p!= nullptr && key != p->key)
        {
            parent = p;
            if (key < p->key)
                p = p->left;
            else
                p = p->right;
        }

        if (p != nullptr)
            return false;
        node<K,V>* new_node = new node<K,V>(key,value);

        if (parent == nullptr)
            root = new_node;
        else
        {
            if (new_node->key < parent->key)
                parent->left = new_node;
            else
                parent->right = new_node;
        }

        t_size++;
        return true;
    }
/******************************
*
*Removes a node from the tree without destroying every node beneath it
*@param key: the key to search for to know which node to remove
*
*****************************/
    bool remove(const K& key)
    {
        node<K,V>* p = root;
        node<K, V>* parent = nullptr;
        node<K, V>* replace = nullptr;
        node<K, V>* replace_parent = nullptr;


        while (p != nullptr && key != p->key)
        {
            parent = p;
            if (key < p->key)
                p = p->left;
            else
                p = p->right;
        }

        if (p == nullptr)
            return false;

        if (p->left == nullptr)
            replace = p->right;
        else if (p->right == nullptr)
            replace = p->left;
        else
        {
            replace_parent = p;
            replace = p->left;

            while (replace->right != nullptr)
            {
                replace_parent = replace;
                replace = replace->right;
            }

            if (replace_parent!= p)
            {
                replace_parent->right = replace->left;
                replace->left = p->left;
            }

            replace->right = p->right;
        }

        if (parent == nullptr)
            root = replace;
        else
        {
            if (p->key < parent->key)
                parent->left = replace;
            else
                parent->right = replace;
        }

        delete p;
        t_size--;

        return true;
    }
/******************************
*
*
*Recursively clones a tree by copying all values and nodes to a new tree
*@param p: a node to start with
*****************************/
    node<K,V>* clone(node<K, V>* p) const
    {
        if (p != nullptr)
        {
            node<K,V>* new_node = new node<K,V>(p->key, p->value);
            new_node->left = clone(p->left);
            new_node->right = clone(p->right);

            return new_node;
        }
        else
            return nullptr;
    }
/******************************
*
*Traverses through the tree until it finds a match to the passed key
*@param key: The key that is to be matched and returns the node it belongs to
*
*
*****************************/
    const node<K, V>* find(const K& key) const
    {
        node<K,V>* p = root;

        while (p != nullptr && key != p->key)
        {
            if (key < p->key)
                p = p->left;
            else
                p = p->right;
        }

        return p;
    }
/******************************
*
*Recursive initialization to the preorder traversal of the binary tree
*
*
*****************************/
    void preorder() const
    {
         node<K,V>* p = root;
         preorder(p);
    }
/******************************
*
*Recursive function to traverse the binary tree and print the items in preorder sequence
*@param p: the root passed in by the initialization function, or whichever node is passed recursively
*
*
*****************************/
    void preorder(node<K,V>* p) const
    {
        if (p!= nullptr)
        {
            cout << p->key << ": " <<  p->value << endl;
            preorder(p->left);
            preorder(p->right);
        }
    }
/******************************
*
*Initialization to the recursive in-order traversal of the binary tree
*
*
*****************************/
    void inorder() const
    {
        node<K,V>* p = root;
        inorder(p);
    }
/******************************
*
*Recursive function to traverse the binary tree and print the items in in-order sequence
*@param p: the root passed in by the initialization function, or whichever node is passed recursively
*
*
*****************************/
    void inorder(node<K,V>* p) const
    {
        if (p != nullptr)
        {
            inorder(p->left);
            cout << p->key << ": " <<  p->value << endl;
            inorder(p->right);
        }
    }
/******************************
*
*Initialization to the recursive postorder traversal of the binary tree

*
*
*****************************/
    void postorder() const
    {
        node<K,V>* p = root;
        postorder(p);
    }
/******************************
*
*Recursive function to traverse the binary tree and print the items in postorder sequence
*@param p: the root passed in by the initialization function, or whichever node is passed recursively
*
*
*****************************/
    void postorder(node<K,V>* p) const
    {
        if (p != nullptr)
        {
            postorder(p->left);
            postorder(p->right);
            cout << p->key << ": " <<  p->value << endl;
        }
    }
/******************************
*
*Initialization to the recursive level-order traversal of the binary tree
*
*
*****************************/
    void level_order() const
    {
       size_t h = height(root);

       size_t i = 1;
       while (i <= h)
       {
           print_level(root,i);
           i++;
       }
    }
/******************************
*
*Recursive function to traverse the binary tree and print the items in level-order sequence
*@param p: the root passed in by the initialization function, or whichever node is passed recursively
*@param level: the current level that the tree is being searched on
*
*
*****************************/
    void print_level(node<K,V>* p, size_t level) const
    {
        if (p == nullptr)
            return;
        if (level == 1)
            cout << p->key << ": " <<  p->value << endl;
        else if (level > 1)
        {
            print_level(p->left, level - 1);
            print_level(p->right, level - 1);
        }
    }



private:

    node<K,V>* root;
    size_t t_size;

};


#endif //BSTREE

